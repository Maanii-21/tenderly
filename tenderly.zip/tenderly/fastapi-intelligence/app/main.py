from datetime import datetime, timezone
import os
import secrets
from typing import Any

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import JSONResponse

from .db import connection

app = FastAPI(
    title="Tenderly Intelligence API",
    version="1.0.0",
    description="Explainable rule-based matching for construction tender discovery."
)


@app.middleware("http")
async def protect_internal_endpoints(request: Request, call_next):
    if request.url.path.startswith(("/docs", "/openapi.json", "/health")):
        return await call_next(request)
    expected_key = os.environ.get("INTERNAL_API_KEY", "")
    provided_key = request.headers.get("X-Internal-Key", "")
    if not expected_key or not secrets.compare_digest(provided_key, expected_key):
        return JSONResponse(status_code=401, content={"detail": "Internal API key is required."})
    return await call_next(request)


def get_company(company_id: str) -> dict[str, Any]:
    with connection() as conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM organizations WHERE id = %s", (company_id,))
        company = cur.fetchone()
        if not company:
            raise HTTPException(404, "Company not found")
        cur.execute("SELECT state FROM organization_regions WHERE organization_id = %s", (company_id,))
        company["states"] = {row["state"] for row in cur.fetchall()}
        cur.execute("SELECT capability FROM organization_capabilities WHERE organization_id = %s", (company_id,))
        company["capabilities"] = {row["capability"] for row in cur.fetchall()}
        cur.execute("SELECT category FROM organization_projects WHERE organization_id = %s", (company_id,))
        company["project_categories"] = {row["category"] for row in cur.fetchall()}
    return company


def get_tenders() -> list[dict[str, Any]]:
    with connection() as conn, conn.cursor() as cur:
        cur.execute("""SELECT t.*, array_remove(array_agg(tc.category), NULL) AS categories
            FROM tenders t LEFT JOIN tender_categories tc ON tc.tender_id = t.id
            WHERE t.closing_at > NOW() GROUP BY t.id ORDER BY t.closing_at""")
        tenders = cur.fetchall()
        for tender in tenders:
            cur.execute("SELECT requirement_type, requirement_value, is_verified FROM tender_requirements WHERE tender_id = %s", (tender["id"],))
            tender["requirements"] = cur.fetchall()
    return tenders


def assess(company: dict[str, Any], tender: dict[str, Any]) -> dict[str, Any]:
    categories = set(tender["categories"] or [])
    matched_capabilities = sorted(categories & company["capabilities"])
    matched_projects = sorted(categories & company["project_categories"])
    region_match = tender["state"] in company["states"]
    days_remaining = max((tender["closing_at"] - datetime.now(timezone.utc)).days, 0)

    # The score is intentionally simple so a bid team can challenge every point.
    score = 0
    reasons = []
    if matched_capabilities:
        score += 45
        reasons.append(f"Capability match: {', '.join(matched_capabilities)} (+45)")
    if region_match:
        score += 25
        reasons.append(f"Operating presence in {tender['state']} (+25)")
    if matched_projects:
        score += 20
        reasons.append(f"Comparable completed project category: {', '.join(matched_projects)} (+20)")
    if days_remaining >= 7:
        score += 10
        reasons.append("At least seven days remain to prepare a bid (+10)")
    elif days_remaining > 0:
        reasons.append("Short preparation window: less than seven days remain (+0)")

    verified = [item for item in tender["requirements"] if item["is_verified"]]
    gaps = []
    for item in verified:
        if item["requirement_type"] == "capability" and item["requirement_value"] not in company["capabilities"]:
            gaps.append(f"Missing required capability: {item['requirement_value']}")
    data_warning = None if verified else "Eligibility requirements have not been verified from the official tender document."
    readiness = "ready" if score >= 70 and not gaps else "review" if score >= 45 else "low_fit"
    bid_guidance = "No official cost estimate is present in this source snapshot. Do not generate a bid price until the BOQ and official tender documents are reviewed."
    if tender["estimated_value_inr"]:
        bid_guidance = f"Reference estimate is INR {tender['estimated_value_inr']:,.0f}; validate quantities, market rates, risk allowance, and margin with a qualified estimator."

    return {
        "tender_id": str(tender["id"]), "reference_number": tender["reference_number"], "title": tender["title"],
        "fit_score": min(score, 100), "readiness": readiness, "reasons": reasons,
        "eligibility_gaps": gaps, "data_warning": data_warning, "bid_guidance": bid_guidance,
        "source_url": tender["source_url"], "closing_at": tender["closing_at"],
    }


@app.get("/health")
def health() -> dict[str, str]:
    with connection() as conn, conn.cursor() as cur:
        cur.execute("SELECT 1")
    return {"status": "ok", "service": "intelligence"}


@app.get("/v1/matches/{company_id}")
def matches(company_id: str, minimum_score: int = Query(default=0, ge=0, le=100)) -> dict[str, Any]:
    company = get_company(company_id)
    items = [assess(company, tender) for tender in get_tenders()]
    items = [item for item in items if item["fit_score"] >= minimum_score]
    return {"company_id": company_id, "matching_method": "explainable_rules_v1", "items": sorted(items, key=lambda item: item["fit_score"], reverse=True)}


@app.get("/v1/tenders/{tender_id}/insight")
def tender_insight(tender_id: str, company_id: str) -> dict[str, Any]:
    company = get_company(company_id)
    tender = next((item for item in get_tenders() if str(item["id"]) == tender_id), None)
    if not tender:
        raise HTTPException(404, "Tender not found or already closed")
    return assess(company, tender)
