# Tenderly Backend

A SaaS starter for real-estate developers, contractors, and consultants who need to discover, assess, and track construction tenders.

It contains two small services:

- **Node.js API gateway**: authentication, company profile, tender catalogue, saved tenders, and dashboard counts.
- **FastAPI intelligence service**: transparent tender matching, eligibility-gap checks, bid readiness, and simple pricing guidance.
- **Next.js frontend**: dashboard and local AI-assistant demo.

Both backend services use one PostgreSQL database.

## Start locally

1. Install Docker Desktop.
2. Copy `.env.example` to `.env` and change the JWT secret.
3. From this folder, run:

   ```bash
   docker compose up --build
   ```

4. Open the website and API documentation:
   - Website: `http://localhost:3001`
   - Gateway: `http://localhost:3000/docs`
   - Intelligence service: `http://localhost:8000/docs`

5. To run the frontend by itself (without Docker):
   - `cd frontend`
   - `npm install`
   - `npm run dev`
   - Open `http://localhost:3000`

   The standalone frontend uses demo dashboard data and its local assistant route. The tender APIs are available through the Docker stack above.

The database creates tables and data the first time its volume starts. To recreate the seeded data, run `docker compose down -v` and then start again.

## Demo login

`owner@buildwise.in` / `Welcome123!`

## Example flow

```bash
# 1. Sign in and copy the token from the response.
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"owner@buildwise.in","password":"Welcome123!"}'

# 2. Browse tenders.
curl http://localhost:3000/api/tenders?state=Delhi

# 3. Get explainable matches for the demo company.
curl http://localhost:8000/v1/matches/11111111-1111-1111-1111-111111111111
```

## Data provenance

`data/official_tender_snapshot.json` stores a dated snapshot of official portal listings retrieved on 22 July 2026. The source records include published titles, tender references, dates, and source URLs only. Values marked `scoring_assumption` in the seed file are demo enrichment for showing the matching engine; they are **not** tender-authority requirements. Before a production bid decision, always download and review the official tender document.

## Project layout

```text
database/                 PostgreSQL schema and seed data
node-api/                 Express API gateway
fastapi-intelligence/     Matching and recommendation service
frontend/                 React + Next.js dashboard with AI assistant
data/                     Source snapshot and provenance notes
docker-compose.yml        Local development stack
```

## Beginner-friendly design choices

- SQL is kept in one readable schema file instead of hidden behind an ORM.
- The scoring formula is a documented weighted rule, not a black-box model.
- Every endpoint has basic validation and tenant ownership checks.
- Environment variables are collected in `.env.example`.

## Production next steps

Add a managed PostgreSQL instance, a task queue for portal ingestion/document OCR, object storage for tender files, rate limits, refresh tokens, audit logging, tenant-level RLS, and a trained probability model after sufficient verified historical outcomes are available.
