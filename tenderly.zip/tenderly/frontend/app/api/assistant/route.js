import { NextResponse } from 'next/server';
import { getAssistantResponse } from '../../../lib/assistantModel';

export async function POST(request) {
  const body = await request.json();
  const question = typeof body.question === 'string' ? body.question.trim() : '';
  if (!question) {
    return NextResponse.json({ error: 'Question is required.' }, { status: 400 });
  }
  const answer = getAssistantResponse(question);
  return NextResponse.json({ answer });
}
