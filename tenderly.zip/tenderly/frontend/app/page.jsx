'use client';

import { useState } from 'react';
import { stats, properties, updates } from '../lib/sampleData';

function StatCard({ label, value, detail, accent }) {
  return (
    <div className="card glow-card" style={{ padding: '22px' }}>
      <p className="label">{label}</p>
      <h3 style={{ margin: '16px 0 8px', fontSize: '2rem', color: accent }}>{value}</h3>
      <p className="subtle">{detail}</p>
    </div>
  );
}

function PropertyCard({ property }) {
  return (
    <div className="card" style={{ padding: '24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: '16px', flexWrap: 'wrap' }}>
        <div>
          <p className="label">{property.category}</p>
          <h3 style={{ margin: '10px 0 8px', fontSize: '1.4rem' }}>{property.title}</h3>
          <p className="subtle">{property.location}</p>
        </div>
        <span className="accent-pill">{property.status}</span>
      </div>
      <div style={{ marginTop: '20px' }}>
        <p style={{ fontSize: '1.2rem', fontWeight: 700 }}>{property.price}</p>
        <p className="subtle" style={{ marginTop: '10px' }}>{property.progress}</p>
        <p className="subtle" style={{ marginTop: '8px' }}>{property.trend}</p>
      </div>
    </div>
  );
}

function UpdateCard({ update }) {
  return (
    <div className="card" style={{ padding: '20px' }}>
      <p className="label">Update</p>
      <h3 style={{ margin: '12px 0 8px', fontSize: '1.2rem' }}>{update.title}</h3>
      <p className="subtle">{update.note}</p>
    </div>
  );
}

export default function Home() {
  const [question, setQuestion] = useState('How can I improve my property pipeline this quarter?');
  const [answer, setAnswer] = useState('Use a mix of verified bid-ready tenders, buyer matching, and quick follow-up on high-fit listings. Keep the focus on projects with strong regional demand.');
  const [loading, setLoading] = useState(false);

  async function handleAsk(event) {
    event.preventDefault();
    setLoading(true);
    setAnswer('Thinking...');
    try {
      const response = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question })
      });
      const data = await response.json();
      setAnswer(data.answer || 'The assistant is unavailable. Try again in a moment.');
    } catch (error) {
      setAnswer('Unable to connect to the assistant. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="container">
      <section style={{ marginBottom: '32px' }}>
        <div className="card glow-card" style={{ padding: '34px', display: 'flex', justifyContent: 'space-between', gap: '24px', flexWrap: 'wrap' }}>
          <div style={{ maxWidth: '680px' }}>
            <p className="label">Tenderly for Real Estate Owners</p>
            <h1 className="section-title">Manage listings, inspect tender fit, and grow deals with AI-ready insights.</h1>
            <p className="subtle" style={{ marginTop: '18px', maxWidth: '680px' }}>
              One dashboard to track projects, shortlist high-value opportunities, and ask for fast business guidance.
            </p>
          </div>
          <div style={{ minWidth: '260px', padding: '24px', borderRadius: '18px', background: 'linear-gradient(180deg, rgba(91, 140, 255, 0.18), rgba(108, 99, 255, 0.12))' }}>
            <p className="label">Live example</p>
            <p style={{ margin: '16px 0 8px', fontSize: '1.6rem', fontWeight: 700 }}>Ready to scale bids</p>
            <p className="subtle">Check nearby tenders, share team notes, and keep an eye on bid readiness.</p>
          </div>
        </div>
      </section>

      <section style={{ marginBottom: '32px' }}>
        <div className="grid grid-4">
          {stats.map((item) => (
            <StatCard key={item.id} {...item} />
          ))}
        </div>
      </section>

      <section style={{ marginBottom: '32px' }}>
        <div className="card" style={{ padding: '28px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '16px', flexWrap: 'wrap' }}>
            <div>
              <p className="label">Opportunity pipeline</p>
              <h2 className="section-title" style={{ margin: '10px 0 0' }}>Top prospects this week</h2>
            </div>
            <button className="primary">View full pipeline</button>
          </div>
          <div className="grid grid-3" style={{ marginTop: '24px' }}>
            {properties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        </div>
      </section>

      <section style={{ marginBottom: '32px' }}>
        <div className="grid grid-2">
          <div className="card" style={{ padding: '26px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
              <div>
                <p className="label">AI Assistant</p>
                <h2 className="section-title" style={{ margin: '10px 0 0' }}>Ask the system for strategy</h2>
              </div>
              <span className="accent-pill">AI powered</span>
            </div>
            <form onSubmit={handleAsk} className="input-group" style={{ marginTop: '24px' }}>
              <textarea
                className="input-field"
                value={question}
                onChange={(event) => setQuestion(event.target.value)}
                aria-label="Ask AI assistant"
              />
              <button type="submit" className="primary" disabled={loading}>{loading ? 'Analyzing...' : 'Get guidance'}</button>
            </form>
            <div style={{ marginTop: '24px', padding: '20px', borderRadius: '16px', background: 'rgba(14, 17, 32, 0.9)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <p className="label">Suggestion</p>
              <p style={{ marginTop: '14px', fontSize: '1rem', color: '#D1D5DB', lineHeight: 1.8 }}>{answer}</p>
            </div>
          </div>

          <div className="card" style={{ padding: '26px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
              <div>
                <p className="label">Recent alerts</p>
                <h2 className="section-title" style={{ margin: '10px 0 0' }}>Latest business signals</h2>
              </div>
              <span className="accent-pill">Focus now</span>
            </div>
            <div className="grid grid-2" style={{ marginTop: '24px' }}>
              {updates.map((update) => (
                <UpdateCard key={update.id} update={update} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <footer className="footer">
        <p>Tenderly SaaS dashboard for real estate business owners — clean, modern, and easy to navigate.</p>
      </footer>
    </main>
  );
}
