import './globals.css';

export const metadata = {
  title: 'Tenderly | Real Estate SaaS',
  description: 'A beginner-friendly real estate business dashboard with AI guidance.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
