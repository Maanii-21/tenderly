# Tenderly Frontend

A beginner-friendly React + Next.js dashboard for real estate business owners.

## Run locally

1. Open this folder in a terminal.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```
4. Open `http://localhost:3000` in your browser.

## Features

- Dark glassmorphism dashboard with gradients and soft shadows.
- Property, pipeline, and lead cards for real estate owners.
- Built-in AI assistant route for quick business advice.
- Easy-to-read code with separate components and sample data.
