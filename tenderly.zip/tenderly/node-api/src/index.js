import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query } from './db.js';
import { requireAuth } from './middleware/auth.js';

const app = express();
const port = Number(process.env.PORT || 3000);
const intelligenceUrl = process.env.INTELLIGENCE_URL || 'http://localhost:8000';
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.get('/health', async (_req, res) => {
  await query('SELECT 1');
  res.json({ status: 'ok', service: 'gateway' });
});

app.get('/docs', (_req, res) => res.json({
  service: 'Tenderly gateway',
  endpoints: ['POST /api/auth/login', 'GET /api/me', 'GET /api/dashboard', 'GET /api/tenders', 'GET /api/tenders/:id', 'POST /api/tenders/:id/save', 'GET /api/matches']
}));

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email and password are required.' });
  const result = await query('SELECT id, organization_id, full_name, email, password_hash, role FROM users WHERE email = $1', [email.toLowerCase()]);
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Incorrect email or password.' });
  const token = jwt.sign({ sub: user.id, organizationId: user.organization_id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '8h' });
  res.json({ token, user: { id: user.id, fullName: user.full_name, email: user.email, role: user.role, organizationId: user.organization_id } });
});

app.get('/api/me', requireAuth, async (req, res) => {
  const company = await query('SELECT id, name, registration_number, employee_count, annual_turnover_inr, credit_rating FROM organizations WHERE id = $1', [req.user.organizationId]);
  const [regions, capabilities, certifications, projects] = await Promise.all([
    query('SELECT state, city FROM organization_regions WHERE organization_id = $1 ORDER BY state, city', [req.user.organizationId]),
    query('SELECT capability, years_experience FROM organization_capabilities WHERE organization_id = $1 ORDER BY capability', [req.user.organizationId]),
    query('SELECT certification, valid_until FROM organization_certifications WHERE organization_id = $1 ORDER BY certification', [req.user.organizationId]),
    query('SELECT project_name, category, location, contract_value_inr, completed_on FROM organization_projects WHERE organization_id = $1 ORDER BY completed_on DESC', [req.user.organizationId])
  ]);
  res.json({ ...company.rows[0], regions: regions.rows, capabilities: capabilities.rows, certifications: certifications.rows, completedProjects: projects.rows });
});

app.get('/api/dashboard', requireAuth, async (req, res) => {
  const orgId = req.user.organizationId;
  const result = await query(`SELECT
    (SELECT count(*) FROM tenders WHERE closing_at > NOW()) AS open_tenders,
    (SELECT count(*) FROM saved_tenders WHERE organization_id = $1 AND status = 'shortlisted') AS shortlisted,
    (SELECT count(*) FROM saved_tenders WHERE organization_id = $1 AND status IN ('bidding','submitted')) AS active_bids`, [orgId]);
  res.json(result.rows[0]);
});

app.get('/api/tenders', requireAuth, async (req, res) => {
  const { state, category, q, limit = '25', offset = '0' } = req.query;
  const values = [];
  const filters = [];
  if (state) { values.push(state); filters.push(`t.state = $${values.length}`); }
  if (q) { values.push(`%${q}%`); filters.push(`(t.title ILIKE $${values.length} OR t.reference_number ILIKE $${values.length})`); }
  if (category) { values.push(category); filters.push(`EXISTS (SELECT 1 FROM tender_categories tc WHERE tc.tender_id = t.id AND tc.category = $${values.length})`); }
  values.push(Math.min(Math.max(Number(limit) || 25, 1), 100), Math.max(Number(offset) || 0, 0));
  const where = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
  const sql = `SELECT t.*, array_remove(array_agg(tc.category), NULL) AS categories
    FROM tenders t LEFT JOIN tender_categories tc ON tc.tender_id = t.id ${where}
    GROUP BY t.id ORDER BY t.closing_at ASC LIMIT $${values.length - 1} OFFSET $${values.length}`;
  const result = await query(sql, values);
  res.json({ items: result.rows, limit: values.at(-2), offset: values.at(-1) });
});

app.get('/api/tenders/:id', requireAuth, async (req, res) => {
  const tender = await query('SELECT * FROM tenders WHERE id = $1', [req.params.id]);
  if (!tender.rows[0]) return res.status(404).json({ error: 'Tender not found.' });
  const [categories, requirements] = await Promise.all([
    query('SELECT category FROM tender_categories WHERE tender_id = $1', [req.params.id]),
    query('SELECT requirement_type, requirement_value, is_verified FROM tender_requirements WHERE tender_id = $1', [req.params.id])
  ]);
  res.json({ ...tender.rows[0], categories: categories.rows.map((row) => row.category), requirements: requirements.rows });
});

app.post('/api/tenders/:id/save', requireAuth, async (req, res) => {
  const status = req.body.status || 'watching';
  const allowed = ['watching', 'shortlisted', 'bidding', 'submitted', 'not_pursuing'];
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid saved-tender status.' });
  const exists = await query('SELECT 1 FROM tenders WHERE id = $1', [req.params.id]);
  if (!exists.rowCount) return res.status(404).json({ error: 'Tender not found.' });
  const result = await query(`INSERT INTO saved_tenders (organization_id, tender_id, status, notes)
    VALUES ($1, $2, $3, $4) ON CONFLICT (organization_id, tender_id)
    DO UPDATE SET status = EXCLUDED.status, notes = EXCLUDED.notes RETURNING *`, [req.user.organizationId, req.params.id, status, req.body.notes || null]);
  res.status(201).json(result.rows[0]);
});

app.get('/api/matches', requireAuth, async (req, res) => {
  const response = await fetch(`${intelligenceUrl}/v1/matches/${req.user.organizationId}`, {
    headers: { 'X-Internal-Key': process.env.INTERNAL_API_KEY }
  });
  if (!response.ok) return res.status(502).json({ error: 'Intelligence service is unavailable.' });
  res.json(await response.json());
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ error: 'Unexpected server error.' });
});

app.listen(port, () => console.log(`Gateway listening on port ${port}`));
