CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  registration_number TEXT UNIQUE,
  employee_count INTEGER CHECK (employee_count >= 0),
  annual_turnover_inr NUMERIC(16,2) CHECK (annual_turnover_inr >= 0),
  credit_rating TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'owner' CHECK (role IN ('owner', 'manager', 'analyst')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE organization_regions (
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  state TEXT NOT NULL,
  city TEXT,
  PRIMARY KEY (organization_id, state, city)
);

CREATE TABLE organization_capabilities (
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  capability TEXT NOT NULL,
  years_experience NUMERIC(4,1) CHECK (years_experience >= 0),
  PRIMARY KEY (organization_id, capability)
);

CREATE TABLE organization_certifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  certification TEXT NOT NULL,
  valid_until DATE,
  UNIQUE (organization_id, certification)
);

CREATE TABLE organization_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  project_name TEXT NOT NULL,
  category TEXT NOT NULL,
  location TEXT,
  contract_value_inr NUMERIC(16,2) CHECK (contract_value_inr >= 0),
  completed_on DATE
);

CREATE TABLE tenders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_number TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  procuring_entity TEXT,
  tender_type TEXT NOT NULL DEFAULT 'works',
  state TEXT,
  city TEXT,
  published_at TIMESTAMPTZ,
  closing_at TIMESTAMPTZ NOT NULL,
  opening_at TIMESTAMPTZ,
  estimated_value_inr NUMERIC(16,2),
  source_url TEXT NOT NULL,
  source_retrieved_at TIMESTAMPTZ NOT NULL,
  source_status TEXT NOT NULL DEFAULT 'official_snapshot',
  description TEXT,
  scoring_assumption BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE tender_categories (
  tender_id UUID NOT NULL REFERENCES tenders(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  PRIMARY KEY (tender_id, category)
);

-- Requirements are only populated when verified from the original tender document.
CREATE TABLE tender_requirements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tender_id UUID NOT NULL REFERENCES tenders(id) ON DELETE CASCADE,
  requirement_type TEXT NOT NULL CHECK (requirement_type IN ('capability', 'certification', 'minimum_turnover', 'minimum_experience_years', 'document')),
  requirement_value TEXT NOT NULL,
  is_verified BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE saved_tenders (
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  tender_id UUID NOT NULL REFERENCES tenders(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'watching' CHECK (status IN ('watching', 'shortlisted', 'bidding', 'submitted', 'not_pursuing')),
  notes TEXT,
  saved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (organization_id, tender_id)
);

CREATE TABLE tender_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tender_id UUID NOT NULL REFERENCES tenders(id) ON DELETE CASCADE,
  document_name TEXT NOT NULL,
  storage_key TEXT NOT NULL,
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX tenders_closing_at_idx ON tenders(closing_at);
CREATE INDEX tenders_state_idx ON tenders(state);
CREATE INDEX tender_categories_category_idx ON tender_categories(category);
CREATE INDEX saved_tenders_organization_idx ON saved_tenders(organization_id);
