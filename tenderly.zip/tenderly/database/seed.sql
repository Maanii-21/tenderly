-- All tender title/reference/date fields below are an official portal snapshot retrieved on 2026-07-22.
-- Category, geography, and estimated values marked as scoring assumptions are deliberately separate from source facts.
INSERT INTO organizations (id, name, registration_number, employee_count, annual_turnover_inr, credit_rating)
VALUES ('11111111-1111-1111-1111-111111111111', 'BuildWise Projects Pvt Ltd', 'U45201DL2017PTC000101', 86, 185000000.00, 'BBB+')
ON CONFLICT (id) DO NOTHING;

INSERT INTO users (id, organization_id, full_name, email, password_hash, role)
VALUES ('22222222-2222-2222-2222-222222222222', '11111111-1111-1111-1111-111111111111', 'Aarav Mehta', 'owner@buildwise.in', crypt('Welcome123!', gen_salt('bf', 10)), 'owner')
ON CONFLICT (email) DO NOTHING;

INSERT INTO organization_regions (organization_id, state, city) VALUES
('11111111-1111-1111-1111-111111111111', 'Delhi', 'New Delhi'),
('11111111-1111-1111-1111-111111111111', 'Maharashtra', 'Nagpur'),
('11111111-1111-1111-1111-111111111111', 'Jharkhand', 'Ranchi');

INSERT INTO organization_capabilities (organization_id, capability, years_experience) VALUES
('11111111-1111-1111-1111-111111111111', 'civil_construction', 11),
('11111111-1111-1111-1111-111111111111', 'roads_and_bridges', 7),
('11111111-1111-1111-1111-111111111111', 'building_renovation', 9),
('11111111-1111-1111-1111-111111111111', 'facility_management', 5);

INSERT INTO organization_certifications (organization_id, certification, valid_until) VALUES
('11111111-1111-1111-1111-111111111111', 'ISO 9001', '2027-06-30'),
('11111111-1111-1111-1111-111111111111', 'ISO 45001', '2027-06-30'),
('11111111-1111-1111-1111-111111111111', 'RERA registration', '2028-03-31');

INSERT INTO organization_projects (organization_id, project_name, category, location, contract_value_inr, completed_on) VALUES
('11111111-1111-1111-1111-111111111111', 'District office rehabilitation', 'building_renovation', 'New Delhi', 28000000, '2025-08-30'),
('11111111-1111-1111-1111-111111111111', 'Urban approach road package', 'roads_and_bridges', 'Nagpur', 61000000, '2025-02-28'),
('11111111-1111-1111-1111-111111111111', 'Community health centre extension', 'civil_construction', 'Ranchi', 39000000, '2024-11-15');

INSERT INTO tenders (id, reference_number, title, procuring_entity, state, city, closing_at, opening_at, source_url, source_retrieved_at, description, scoring_assumption) VALUES
('30000000-0000-0000-0000-000000000001', 'TCIL/C/PD(CG)/EMRS/2026/46', 'Construction of Eklavya Model Residential School at Shampur, Block Makdi, District Kondagaon, Chhattisgarh', 'Telecommunications Consultants India Limited', 'Chhattisgarh', 'Kondagaon', '2026-08-08 15:00:00+05:30', '2026-08-10 15:00:00+05:30', 'https://etenders.gov.in/', '2026-07-22 00:00:00+05:30', 'Official listing snapshot; detailed eligibility must be verified in source documents.', FALSE),
('30000000-0000-0000-0000-000000000002', 'HITES/IDN/CCL-RANCHI/2026-27', 'Construction of a Super Speciality Hospital at Kanke, Ranchi', 'HITES', 'Jharkhand', 'Ranchi', '2026-08-11 15:00:00+05:30', '2026-08-12 15:00:00+05:30', 'https://etenders.gov.in/eprocure/app?component=%24DirectLink&page=FrontEndViewTender', '2026-07-22 00:00:00+05:30', 'Official listing snapshot; detailed eligibility must be verified in source documents.', FALSE),
('30000000-0000-0000-0000-000000000003', 'NHAI/RO/NAG/NAN/FOB/26-27/26', 'Fabrication and erection of three Foot Over Bridges with ramps on NH361 in Maharashtra', 'National Highways Authority of India', 'Maharashtra', 'Nagpur', '2026-08-03 11:00:00+05:30', '2026-08-04 11:00:00+05:30', 'https://etenders.gov.in/eprocure/app?page=FrontEndTenderD', '2026-07-22 00:00:00+05:30', 'Official listing snapshot; detailed eligibility must be verified in source documents.', FALSE),
('30000000-0000-0000-0000-000000000004', 'NSCD/15014/1/e-tender/4/26-27', 'Construction of Boundary Wall near Two Wheeler Parking Area at National Science Centre Delhi', 'National Science Centre Delhi', 'Delhi', 'New Delhi', '2026-08-11 15:00:00+05:30', '2026-08-12 15:30:00+05:30', 'https://eprocure.gov.in/eprocure/app?component=%24DirectLink&page=', '2026-07-22 00:00:00+05:30', 'Official listing snapshot; detailed eligibility must be verified in source documents.', FALSE),
('30000000-0000-0000-0000-000000000005', 'JPL/CnM/26-27/1200008522', 'Construction and fabrication of car porch, gazebo and paved walkway at hostel premises', 'Jindal Power Limited', 'Chhattisgarh', NULL, '2026-07-28 18:00:00+05:30', '2026-07-29 09:00:00+05:30', 'https://etenders.gov.in/eprocure/app?page=FrontEndTenderD', '2026-07-22 00:00:00+05:30', 'Official listing snapshot; detailed eligibility must be verified in source documents.', FALSE),
('30000000-0000-0000-0000-000000000006', 'EE(M-II)/RZ/2026-27/16/08', 'Improvement and development of roads and links in A-1 Block, Ward 43 Sultanpuri', 'Municipal Corporation of Delhi', 'Delhi', 'Sultanpuri', '2026-07-27 15:00:00+05:30', '2026-07-27 15:05:00+05:30', 'https://etenders.gov.in/eprocure/app?component=%24DirectLink&page=FrontEndViewTender', '2026-07-22 00:00:00+05:30', 'Official listing snapshot; detailed eligibility must be verified in source documents.', FALSE),
('30000000-0000-0000-0000-000000000007', '19/EEC/BSNL-Civil/JDR/2026-27', 'Repairing and plastering of terrace to prevent leakage at Mahaveer Nagar office building', 'BSNL Civil, Jodhpur', 'Rajasthan', 'Pali', '2026-07-28 18:00:00+05:30', '2026-08-03 15:30:00+05:30', 'https://etenders.gov.in/eprocure/app?component=%24DirectLink&page=FrontEndViewTender', '2026-07-22 00:00:00+05:30', 'Official listing snapshot; detailed eligibility must be verified in source documents.', FALSE),
('30000000-0000-0000-0000-000000000008', 'NHAI/13012/229/RO/OD/1372/26', 'Construction of FOB with Ramp at Ch 566.840 on NH 53 in Odisha on EPC Mode', 'National Highways Authority of India', 'Odisha', NULL, '2026-08-13 11:00:00+05:30', '2026-08-14 12:30:00+05:30', 'https://etenders.gov.in/eprocure/app?component=%24DirectLink_11&page=FrontEndTenderDetails&service=direct', '2026-07-22 00:00:00+05:30', 'Official listing snapshot; detailed eligibility must be verified in source documents.', FALSE);

INSERT INTO tender_categories (tender_id, category) VALUES
('30000000-0000-0000-0000-000000000001', 'civil_construction'),
('30000000-0000-0000-0000-000000000002', 'civil_construction'),
('30000000-0000-0000-0000-000000000003', 'roads_and_bridges'),
('30000000-0000-0000-0000-000000000004', 'building_renovation'),
('30000000-0000-0000-0000-000000000005', 'civil_construction'),
('30000000-0000-0000-0000-000000000006', 'roads_and_bridges'),
('30000000-0000-0000-0000-000000000007', 'building_renovation'),
('30000000-0000-0000-0000-000000000008', 'roads_and_bridges');

INSERT INTO saved_tenders (organization_id, tender_id, status, notes) VALUES
('11111111-1111-1111-1111-111111111111', '30000000-0000-0000-0000-000000000004', 'shortlisted', 'Nearby project; obtain official BOQ and eligibility documents.'),
('11111111-1111-1111-1111-111111111111', '30000000-0000-0000-0000-000000000003', 'watching', 'Review bridge-specific credentials before shortlisting.');
